Yiddish pipeline optimized for CPU. Components: tok2vec, tagger, parser, senter, lemmatizer.

| Feature | Description |
| --- | --- |
| **Name** | `yi_yiddish_sm` |
| **Version** | `0.0.1` |
| **spaCy** | `>=3.3.0,<3.4.0` |
| **Default Pipeline** | `tok2vec`, `tagger`, `parser`, `ner` |
| **Components** | `tok2vec`, `tagger`, `parser`, `ner` |
| **Vectors** | 0 keys, 0 unique vectors (0 dimensions) |
| **Sources** | n/a |
| **License** | `MIT` |
| **Author** | [New Languages for NLP](https://newnlp.princeton.edu) |

### Label Scheme

<details>

<summary>View label scheme (25 labels for 3 components)</summary>

| Component | Labels |
| --- | --- |
| **`tagger`** | `ADJ`, `ADP`, `ADV`, `AUX`, `CCONJ`, `DET`, `NOUN`, `NUM`, `PART`, `PRON`, `PROPN`, `PUNCT`, `SCONJ`, `VERB`, `X`, `_` |
| **`parser`** | `ROOT`, `_`, `dep` |
| **`ner`** | `LOC`, `ORG`, `PER`, `m/results\`, `m/watch\`, `null` |

</details>

### Accuracy

| Type | Score |
| --- | --- |
| `TAG_ACC` | 53.57 |
| `DEP_UAS` | 100.00 |
| `DEP_LAS` | 0.00 |
| `SENTS_P` | 100.00 |
| `SENTS_R` | 100.00 |
| `SENTS_F` | 100.00 |
| `ENTS_F` | 0.00 |
| `ENTS_P` | 0.00 |
| `ENTS_R` | 0.00 |
| `TOK2VEC_LOSS` | 0.00 |
| `TAGGER_LOSS` | 21093.75 |
| `PARSER_LOSS` | 0.00 |
| `NER_LOSS` | 10676.92 |